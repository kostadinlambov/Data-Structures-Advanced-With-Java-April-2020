import java.util.function.Consumer;

class AATree<T extends Comparable<T>> {
    public static class Node<T> {
        
    }

    public AATree() {

    }

    public boolean isEmpty() {
        return false;
    }

    public void clear() {

    }

    public void insert(T element) {

    }

    public int countNodes() {
        return -1;
    }

    public boolean search(T element) {
        return false;
    }

    public void inOrder(Consumer<T> consumer) {

    }

    public void preOrder(Consumer<T> consumer) {

    }

    public void postOrder(Consumer<T> consumer) {

    }
}