package models;

public enum HeroType {
    WARRIOR,
    MAGE,
    PALADIN,
    HUNTER,
    DRUID
}
